package com.epam7.designpatterns;

public interface MediaPlayer {
	   public void play(String audioType, String fileName);
}